#!/bin/bash

LD_LIBRARY_PATH=$(pwd)/libs:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH
echo $LD_LIBRARY_PATH
./Dwarfchitect